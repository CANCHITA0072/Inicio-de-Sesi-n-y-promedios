﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //try-catch
            try
            {
                //byte texto = Convert.ToByte(txtIngreso.Text);
                //lblMostrar.Text = texto.ToString();
                //string usuario = txtIngreso.Text;

                if(txtIngreso.Text == "Ana" && txtContra.Text =="1234") 
                {
                    this.Hide();
                    Programa frm = new Programa();
                    frm.Show();

                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrecto");
                }
            }

            catch (OverflowException y)
            {
                MessageBox.Show("El error es:" + y);
            }
            catch (FormatException v)
            {
                MessageBox.Show("El error es:" + v);
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
